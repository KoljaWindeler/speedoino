#ifndef SYSCALLS_H_
#define SYSCALLS_H_

#include <reent.h>


#endif
